#pragma once

double getTimeDeltaSeconds();